import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  noOfProductViews:number=0;

  parentFunc1(evt:any):void{
    console.log(`Got an event from the child ${evt}`);
    this.noOfProductViews=evt;
  }

}