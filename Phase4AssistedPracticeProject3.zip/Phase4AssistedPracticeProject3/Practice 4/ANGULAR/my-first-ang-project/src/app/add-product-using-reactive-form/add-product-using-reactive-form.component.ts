import { Component } from '@angular/core';

@Component({
  selector: 'app-add-product-using-reactive-form',
  templateUrl: './add-product-using-reactive-form.component.html',
  styleUrls: ['./add-product-using-reactive-form.component.css']
})
export class AddProductUsingReactiveFormComponent {

}
