import { Component } from '@angular/core';
import { Product } from '../classes/product';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {

  //products: Product[] = [];

  products: Product[] = [
    new Product("Laptop", 60000,"assets/images/laptoop.jpg", true, true),
    new Product("Keyboard", 560, "assets/images/keyboard.jpg", false, true),
    new Product("Mouse", 600,'assets/images/Mouse.jpg', false, false),
    new Product("Monitor", 20000,'assets/images/Monitor.jpg', true, false),
  ]

}